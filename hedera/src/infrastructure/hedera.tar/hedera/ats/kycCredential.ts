import { createRequire } from "node:module";
import { dirname, join } from "node:path";

import { env } from "../config.js";

const require = createRequire(import.meta.url);

const sdkRoot = dirname(
  require.resolve("@hashgraph/asset-tokenization-sdk"),
);

/*
 * The Terminal3 VC libraries (@terminal3/ecdsa_vc, @terminal3/vc_core)
 * are part of the ATS SDK dependency graph and ship as plain CommonJS.
 * They are loaded through the same CJS graph as the ATS SDK so FACTORED
 * keeps a single VC/crypto stack (no ESM/CJS split).
 */
const ecdsaVc: any = require("@terminal3/ecdsa_vc");
const vcCore: any = require("@terminal3/vc_core");

/*
 * ATS internal classes, loaded through the same CJS graph (same
 * dependency container as Network/Kyc/etc.) as in ats.ts.
 */
const Injectable = require(
  join(sdkRoot, "core/injectable/Injectable.js"),
).default;

const { MirrorNodeAdapter } = require(
  join(sdkRoot, "port/out/mirror/MirrorNodeAdapter.js"),
);

export interface InvestorKycDecision {
  /** ATS security representing the FACTORED receivable note. */
  securityId: string;
  /** FACTORED investor Hedera account id (KYC target). */
  investorAccountId: string;
  /** FACTORED receivable reference recorded as a VC claim. */
  receivableId?: string;
}

export interface IssuedInvestorKycVc {
  vc: Record<string, unknown>;
  vcBase64: string;
  issuerDid: string;
  holderDid: string;
}

/**
 * Resolve the EVM address of a Hedera account.
 *
 * Uses ATS's own mirror adapter (axios-based) — the exact component
 * AccountService.getAccountEvmAddress() uses. This keeps a single
 * identity mapping: the holder DID is built from the same address
 * that ATS will resolve and verify for the KYC target.
 *
 * Note: this deliberately avoids Node's global fetch. undici does not
 * honor HTTPS_PROXY environment variables, while the ATS mirror adapter
 * (axios) does.
 *
 * Requires initializeATS() to have been called (Network.init configures
 * the mirror adapter).
 */
export async function resolveAccountEvmAddress(
  accountId: string,
): Promise<string> {
  const mirrorNodeAdapter = Injectable.resolve(MirrorNodeAdapter);

  if (!mirrorNodeAdapter.mirrorNodeConfig) {
    throw new Error(
      "Mirror node adapter is not configured. Call initializeATS() first.",
    );
  }

  const evmAddress = await mirrorNodeAdapter.accountToEvmAddress(accountId);

  return evmAddress.toString();
}

/**
 * Build the FACTORED investor KYC credential.
 *
 * Relationship (FACTORED architecture):
 *
 *   FACTORED authorization/compliance decision
 *       -> signed Verifiable Credential (issuer = FACTORED SSI issuer)
 *       -> ATS grantKyc()
 *       -> on-chain KYC state
 *       -> investor eligible to receive/hold the tokenized receivable note
 *
 * The credential is an ECDSA-signed W3C VC (EcdsaSecp256k1Signature2019):
 *   - issuer  = did:ethr::<operator EVM address>  (registered SSI issuer)
 *   - holder  = did:ethr::<investor EVM address>  (must equal the KYC target)
 *   - type    = KycCredential
 *   - claims  = kyc: "passed" + FACTORED references
 *
 * The ATS GrantKycCommandHandler verifies the signature against the
 * issuer DID, checks holder == KYC target, and checks the issuer is a
 * registered SSI issuer on the security before executing grantKyc.
 *
 * No revocation registry is embedded: ATS verifies the credential
 * without one, and the FACTORED flow does not require revocation.
 */
export async function createInvestorKycVc(
  input: InvestorKycDecision,
): Promise<IssuedInvestorKycVc> {
  if (!input.securityId) {
    throw new Error("securityId is required");
  }

  if (!input.investorAccountId) {
    throw new Error("investorAccountId is required");
  }

  const investorEvmAddress = await resolveAccountEvmAddress(
    input.investorAccountId,
  );

  // SSI issuer = FACTORED operator (registered on the security via
  // SsiManagement.addIssuer). EthrDID derives the EVM address from the
  // operator's ECDSA key, which is what ATS recovers from the proof.
  const issuer = new ecdsaVc.EthrDID(env.HEDERA_OPERATOR_PRIVATE_KEY);

  // Holder = FACTORED investor. The last ':'-segment of this DID must
  // equal the investor's EVM address that ATS resolves for the target.
  const holder = new vcCore.DID("ethr", investorEvmAddress);

  const claims: Record<string, unknown> = {
    kyc: "passed",
    market: "FACTORED",
    securityId: input.securityId,
    receivableId: input.receivableId ?? null,
  };

  const validFrom = new Date();
  const validUntil = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000);

  const vc = await ecdsaVc.createEcdsaCredential(
    issuer,
    holder,
    claims,
    ["KycCredential"],
    validFrom,
    validUntil,
  );

  return {
    vc,
    vcBase64: Buffer.from(JSON.stringify(vc)).toString("base64"),
    issuerDid: issuer.did,
    holderDid: holder.did,
  };
}
