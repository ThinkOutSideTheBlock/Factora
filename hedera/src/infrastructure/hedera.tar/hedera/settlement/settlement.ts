import { getHederaClient } from "../client.js";
import { env } from "../config.js";
import { createReceivableNote } from "../ats/receivable-note.js";
import { ATSKycAdapter } from "../ats/kyc.js";
import { ClearingAdapter } from "./clearing.js";
import { issueReceivableNote } from "../ats/issue.js";
import { initializeATS } from "../ats/ats.js";
import { settleUsdcFromAllowance } from "../hts/usdc.js";
import { writeAuditEvent } from "../hcs/audit.js";
import type { ApprovedTrade, SettlementResult } from "../types.js";

export class HederaExecutionNotReadyError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "HederaExecutionNotReadyError";
  }
}

export class DealNotConfirmedError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "DealNotConfirmedError";
  }
}

export function assertDealConfirmed(trade: ApprovedTrade): void {
  const { supplierConfirmation: s, investorConfirmation: i } = trade;

  if (!s || !i) {
    throw new DealNotConfirmedError(
      "Both supplier and investor confirmations are required before a debt token can be created.",
    );
  }
  if (s.accountId !== trade.supplierAccountId) {
    throw new DealNotConfirmedError("Supplier confirmation does not match the trade's supplier account.");
  }
  if (i.accountId !== trade.investorAccountId) {
    throw new DealNotConfirmedError("Investor confirmation does not match the trade's investor account.");
  }
  if (s.offerId !== i.offerId) {
    throw new DealNotConfirmedError(
      `Supplier and investor confirmed different offers (${s.offerId} vs ${i.offerId}).`,
    );
  }
  if (s.priceUsd !== i.priceUsd || s.priceUsd !== trade.purchasePriceUsd) {
    throw new DealNotConfirmedError(
      `Price mismatch across confirmations: supplier=${s.priceUsd}, investor=${i.priceUsd}, trade=${trade.purchasePriceUsd}.`,
    );
  }
}

export async function executeApprovedTrade(
  trade: ApprovedTrade,
  isin: string,
): Promise<SettlementResult> {
  assertDealConfirmed(trade);

  if (env.RUN_HEDERA_EXECUTION !== true) {
    throw new HederaExecutionNotReadyError(
      "Set RUN_HEDERA_EXECUTION=true only after ATS signing, clearing, and HTS allowance spikes are green.",
    );
  }

  await initializeATS();
  const client = getHederaClient();
  const auditTxIds: string[] = [];

  // 0. Record mutual confirmation BEFORE anything is minted.
  const dealAudit = await writeAuditEvent(client, env.FACTORED_AUDIT_TOPIC_ID, {
    type: "DEAL_CONFIRMED",
    timestamp: Math.floor(Date.now() / 1000),
    receivableId: trade.receivableId,
    data: {
      offerId: trade.supplierConfirmation.offerId,
      priceUsd: trade.purchasePriceUsd,
      supplierAccountId: trade.supplierAccountId,
      investorAccountId: trade.investorAccountId,
    },
  });
  auditTxIds.push(dealAudit.transactionId);

  // 1. Create receivable note
  const note = await createReceivableNote({
    id: trade.receivableId,
    faceValueUsd: trade.faceValueUsd,
    purchasePriceUsd: trade.purchasePriceUsd,
    maturityTimestamp: trade.maturityTimestamp,
    riskGrade: trade.riskGrade,
    debtorName: trade.debtorName,
    isin,
  });

  const noteAudit = await writeAuditEvent(client, env.FACTORED_AUDIT_TOPIC_ID, {
    type: "NOTE_CREATED",
    timestamp: Math.floor(Date.now() / 1000),
    receivableId: trade.receivableId,
    data: { securityId: note.securityId },
  });
  auditTxIds.push(noteAudit.transactionId);

  // 2. KYC investor

  const kyc = new ATSKycAdapter();
  await kyc.grantInvestorKyc({
    securityId: note.securityId,
    investorAccountId: trade.supplierAccountId,   // supplier, not investor, at this step
    vcBase64: Buffer.from("factored-demo-supplier-credential").toString("base64"),
  });
  // 3. Issue security to supplier
  const issued = await issueReceivableNote(note.securityId, trade.supplierAccountId);
  const issuedAudit = await writeAuditEvent(client, env.FACTORED_AUDIT_TOPIC_ID, {
    type: "NOTE_ISSUED",
    timestamp: Math.floor(Date.now() / 1000),
    receivableId: trade.receivableId,
    data: { securityId: note.securityId, transactionId: issued.transactionId },
  });
  auditTxIds.push(issuedAudit.transactionId);

  // 4. KYC investor BEFORE clearing (unchanged from before)
  await kyc.grantInvestorKyc({
    securityId: note.securityId,
    investorAccountId: trade.investorAccountId,
    vcBase64: Buffer.from("factored-demo-investor-credential").toString("base64"),
  });
  // 4. Clearing
  const clearing = new ClearingAdapter();
  const clearingResult = await clearing.initiateSecurityTransfer({
    securityId: note.securityId,
    partitionId: "0",
    targetId: trade.investorAccountId,
  });

  await writeAuditEvent(client, env.FACTORED_AUDIT_TOPIC_ID, {
    type: "NOTE_CLEARING_INITIATED",
    timestamp: Math.floor(Date.now() / 1000),
    receivableId: trade.receivableId,
    data: { securityId: note.securityId, clearingId: clearingResult.clearingId },
  });

  // 5. Approve clearing
  const clearingApproval = await clearing.approveSecurityTransfer({
    securityId: note.securityId,
    partitionId: "0",
    targetId: trade.investorAccountId,
    clearingId: clearingResult.clearingId,
  });

  // 6. USDC settlement
  const cashTx = await settleUsdcFromAllowance(client, {
    tokenId: env.USDC_TOKEN_ID,
    investorAccountId: trade.investorAccountId,
    supplierAccountId: trade.supplierAccountId,
    amountSmallestUnit: BigInt(Math.round(trade.purchasePriceUsd * 1_000_000)),
  });

  return {
    receivableId: trade.receivableId,
    securityId: note.securityId,
    purchasePriceUsd: trade.purchasePriceUsd,
    tokenizationTxId: note.transactionId,
    issuanceTxId: issued.transactionId,
    clearingTransferTxId: clearingApproval.transactionId ?? cashTx.transactionId?.toString() ?? "",
    auditTxIds,
    status: "EXECUTED",
  };
}